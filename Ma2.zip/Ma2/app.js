// app.js
document.addEventListener('DOMContentLoaded', function() {
    new Vue({
        el: '#app',
        data: {
            altura: null,
            peso: null,
            resultado: null,
            mensagemIMC: '',
            nome: '',
            email: '',
            mensagemContato: '',
            enviado: false
        },
        methods: {
            calcularIMC() {
                const alturaMetros = parseFloat(this.altura);
                const pesoKg = parseFloat(this.peso);
                const imc = (pesoKg / (alturaMetros * alturaMetros)).toFixed(2);
                this.resultado = imc;

                if (imc <= 18.5) {
                    this.mensagemIMC = 'Abaixo do peso';
                } else if (imc >= 18.6 && imc <= 24.9) {
                    this.mensagemIMC = 'Peso normal';
                } else if (imc >= 25 && imc <= 29.9) {
                    this.mensagemIMC = 'Sobrepeso';
                } else if (imc >= 30 && imc <= 34.9) {
                    this.mensagemIMC = 'Obesidade I';
                } else if (imc >= 35 && imc <= 39.9) {
                    this.mensagemIMC = 'Obesidade II';
                } else {
                    this.mensagemIMC = 'Obesidade III';
                }

                // Concatenando a mensagem do IMC com a classificação
                this.mensagemIMC = `Situação: ${this.mensagemIMC}`;
            },
            enviarMensagem() {
                // Armazenar os dados do formulário
                const dadosFormulario = {
                    nome: this.nome,
                    email: this.email,
                    mensagem: this.mensagemContato
                };

                // Simulação do envio de mensagem (aqui pode-se enviar os dados para o backend)
                console.log('Dados do formulário:', dadosFormulario);

                // Exibir mensagem de sucesso
                this.enviado = true;
                setTimeout(() => {
                    this.enviado = false;
                    // Limpar campos do formulário após 3 segundos
                    this.nome = '';
                    this.email = '';
                    this.mensagemContato = '';
                }, 3000);
            }
        }
    });
});
